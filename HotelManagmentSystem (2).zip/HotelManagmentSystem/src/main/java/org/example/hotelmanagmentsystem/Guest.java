package org.example.hotelmanagmentsystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Guest implements User{
    private String Username;
    private String Password;
    private String EmailAddress;
    private String PhoneNumber;
    private boolean canBook;
    private double Payment;

    //Methods


    public void SignUp(){
        try (BufferedWriter fileWriter = new BufferedWriter(new FileWriter("guest.txt", true))) {
            fileWriter.append("\n").append("\n").append("\n").append("\n").append(this.Username).append("\n").append(this.Password).append("\n").append(this.EmailAddress).append("\n").append(this.PhoneNumber);
            fileWriter.flush();
        } catch (IOException e) {
           // System.out.println("Error writing to file: " + e.getMessage());
        }
    }
    public void Book(){

    }
    public void Pay(){

    }
    public void ServiceRequest(){

    }
    /**
     *
     */
    @Override
    public boolean Login(String user,String pass) throws IOException {
        boolean find=false;

        BufferedReader br=new BufferedReader(new FileReader("guest.txt"));
        List<Guest>guestList=new ArrayList<>();

            String username=br.readLine();
            String password=br.readLine();
            String phone=br.readLine();
            String email=br.readLine();
            while(email!=null) {
                username=br.readLine();
                password = br.readLine();
                phone = br.readLine();
                email = br.readLine();
                Guest guest = new Guest();
                guest.Username = username;
                guest.Password = password;
                guest.EmailAddress = email;
                guest.PhoneNumber = phone;
                guestList.add(guest);
            }
        for (Guest guest:guestList){
            if (user.equals(guest.Username) && pass.equals(guest.Password)) {
                find = true;
                break;
            }else {
                find=false;
            }

        }


        return find;
    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    /**
     *
     */
    @Override
    public void editProfile() {

    }

    /**
     *
     */
    @Override
    public void viewProfile() {

    }
    public void setUsernameAndPass(String username,String password,String emailAddress,String phoneNumber){

        this.Username=username;
        this.Password=password;
        this.EmailAddress=emailAddress;
        this.PhoneNumber=phoneNumber;

    }
}
