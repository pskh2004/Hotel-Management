package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Admin implements User{
    @FXML
    public Label messageDone ;
    @FXML
    public TextField roomNumber ;
    @FXML
    public RadioButton RBaddRoom , RBdeleteRoom , RBsuite , RBsingleRoom , RBdoubleRoom ;
    private String Username="Admin";
    private String Password="ADMIN";
    private Single single;
    private Double D_room;
    private Suite suite;
    navigate n = new navigate();

    public void backToWelcome(ActionEvent event) throws IOException {
        n.backToWelcome(event);
    }
    public void doneButton(ActionEvent event) throws IOException {
        if(RBaddRoom.isSelected()){
            addRoom();
        } else if (RBdeleteRoom.isSelected()) {
            deleteRoom();
        }
    }
    public void addRoom() throws IOException {
        messageDone.setText("");
        if(RBaddRoom.isSelected()) {
            List<String> numberSingleRoom = new ArrayList<>();
            String lineNumber ;
            String typeRoom ;
            String available ;
            boolean check = true ;
            if(RBsingleRoom.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Singleroom.txt"));
                lineNumber = br.readLine();
                typeRoom = br.readLine();
                available = br.readLine();
                while(available!=null){
                    numberSingleRoom.add(lineNumber);
                    lineNumber = br.readLine();
                    typeRoom = br.readLine();
                    available = br.readLine();
                }
                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Singleroom.txt",true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                int Number = 0 ;
                for (String number : numberSingleRoom){
                    if(number.equals(roomNumber.getText())){
                        check = false ;
                    }
                }
                if(check) {
                    fw.write(roomNumber.getText() + "\n");
                    fw.write("SingleRoom\n");
                    fw.write("true\n");
                    messageDone.setText("add single room is successfully");
                    Single single = new Single();
                    single.setNumber(Number);
                    List<Single> singleList = new ArrayList<>();
                    singleList.add(single);
                }
                else{
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
            if(RBdoubleRoom.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Doubleroom.txt"));
                lineNumber = br.readLine();
                typeRoom = br.readLine();
                available = br.readLine();
                while(available!=null){
                    numberSingleRoom.add(lineNumber);
                    lineNumber = br.readLine();
                    typeRoom = br.readLine();
                    available = br.readLine();
                }
                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Doubleroom.txt",true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                int Number = 0 ;
                for (String number : numberSingleRoom){
                    if(number.equals(roomNumber.getText())){
                        check = false ;
                    }
                }
                if(check) {
                    fw.write(roomNumber.getText() + "\n");
                    fw.write("DoubleRoom\n");
                    fw.write("true\n");
                    messageDone.setText("add double room is successfully");
                    Double D_room = new Double();
                    D_room.setNumber(Number);
                    List<Double> D_roomList = new ArrayList<>();
                    D_roomList.add(D_room);
                }
                else{
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
            if(RBsuite.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Suite.txt"));
                lineNumber = br.readLine();
                typeRoom = br.readLine();
                available = br.readLine();
                while(available!=null){
                    numberSingleRoom.add(lineNumber);
                    lineNumber = br.readLine();
                    typeRoom = br.readLine();
                    available = br.readLine();
                }
                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Suite.txt",true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                int Number = 0 ;
                for (String number : numberSingleRoom){
                    if(number.equals(roomNumber.getText())){
                        check = false ;
                    }
                }
                if(check) {
                    fw.write(roomNumber.getText() + "\n");
                    fw.write("SuiteRoom\n");
                    fw.write("true\n");
                    messageDone.setText("add suite is successfully");
                    Suite suite = new Suite();
                    suite.setNumber(Number);
                    List<Suite> suiteList = new ArrayList<>();
                    suiteList.add(suite);
                }
                else{
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
        }
    }

    public void deleteRoom() throws IOException {
        BufferedReader br ;
        boolean exist = false ;
        String Line ;
        if(RBdeleteRoom.isSelected()){
            if(RBsuite.isSelected()){
                List<String> suiteinfo = new ArrayList<>() ;
                try {
                    br = new BufferedReader(new FileReader("Suite.txt"));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                Line = br.readLine();
                while(Line!=null){
                    suiteinfo.add(Line) ;
                    Line = br.readLine() ;
                }
                br.close();
                BufferedWriter bw = new BufferedWriter(new FileWriter("Suite.txt"));
                bw.close();
                int c = 0 ;
                FileWriter fw1 = new FileWriter("Suite.txt",true);
                for(String info : suiteinfo){
                    if(info.equals(roomNumber.getText())){
                        exist = true ;
                        c = 2 ;
                    } else if (c==0) {
                        fw1.write(info+"\n");
                    }
                    else
                        c-- ;
                }
                fw1.close();
                if(exist){
                    messageDone.setText("deleted is successfully");
                }
                else{
                    messageDone.setText("suite is not exist");
                }
            }
            if(RBsingleRoom.isSelected()){
                List<String> singleinfo = new ArrayList<>() ;
                try {
                    br = new BufferedReader(new FileReader("Singleroom.txt"));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                Line = br.readLine();
                while(Line!=null){
                    singleinfo.add(Line) ;
                    Line = br.readLine() ;
                }
                br.close();
                BufferedWriter bw = new BufferedWriter(new FileWriter("Singleroom.txt"));
                bw.close();
                int c = 0 ;
                FileWriter fw1 = new FileWriter("Singleroom.txt",true);
                for(String info : singleinfo){
                    if(info.equals(roomNumber.getText())){
                        exist = true ;
                        c = 2 ;
                    } else if (c==0) {
                        fw1.write(info+"\n");
                    }
                    else
                        c-- ;
                }
                fw1.close();
                if(exist){
                    messageDone.setText("deleted is successfully");
                }
                else{
                    messageDone.setText("single room is not exist");
                }
            }
            if(RBdoubleRoom.isSelected()){
                List<String> doubleinfo = new ArrayList<>() ;
                try {
                    br = new BufferedReader(new FileReader("Doubleroom.txt"));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                Line = br.readLine();
                while(Line!=null){
                    doubleinfo.add(Line) ;
                    Line = br.readLine() ;
                }
                br.close();
                BufferedWriter bw = new BufferedWriter(new FileWriter("Doubleroom.txt"));
                bw.close();
                int c = 0 ;
                FileWriter fw1 = new FileWriter("Doubleroom.txt",true);
                for(String info : doubleinfo){
                    if(info.equals(roomNumber.getText())){
                        exist = true ;
                        c = 2 ;
                    } else if (c==0) {
                        fw1.write(info+"\n");
                    }
                    else
                        c-- ;
                }
                fw1.close();
                if(exist){
                    messageDone.setText("deleted is successfully");
                }
                else{
                    messageDone.setText("double room is not exist");
                }
            }
        }
    }


    @Override
    public boolean Login(String user, String pass) throws IOException {
        return this.Username.equals(user) && this.Password.equals(pass);
    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    /**
     *
     */
    @Override
    public void editProfile() {

    }

    /**
     *
     */
    @Override
    public void viewProfile() {

    }
}

