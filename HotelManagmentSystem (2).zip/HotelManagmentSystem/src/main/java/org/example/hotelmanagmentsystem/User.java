package org.example.hotelmanagmentsystem;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface User extends HotelManagement{
    public abstract boolean Login(String user,String pass) throws IOException;
    public abstract void Logout();
    public abstract void editProfile();
    public abstract void viewProfile();
}
