package org.example.hotelmanagmentsystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Reservationist implements User {
    private String Username;
    private String Password;
    private Single single;
    private Double D_room;
    private Suite suite;
    /**
     *
     */
    public  void SignUp(){

        try (BufferedWriter fileWriter = new BufferedWriter(new FileWriter("reservationist.txt", true))) {
            fileWriter.append("\n").append(this.Username).append("\n").append(this.Password).append("\n").append("\n");
            fileWriter.flush();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
    public void Check_in(){

    }
    public void Check_out(){

    }

    @Override
    public boolean Login(String user, String pass) throws IOException {
        boolean find=false;

        BufferedReader br=new BufferedReader(new FileReader("reservationist.txt"));
        List<Reservationist>reservationistList=new ArrayList<>();

        String username=br.readLine();
        String password=br.readLine();
        while(password!=null) {
            username=br.readLine();
            password = br.readLine();
            Reservationist reservationist=new Reservationist();
            reservationist.Username = username;
            reservationist.Password = password;
            reservationistList.add(reservationist);
        }
        for (Reservationist reservationist:reservationistList){
            find = user.equals(reservationist.Username) && pass.equals(reservationist.Password);
            System.out.println(reservationist.Username);
        }


        return find;
    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    /**
     *
     */
    @Override
    public void editProfile() {

    }

    /**
     *
     */
    @Override
    public void viewProfile() {

    }
    public void setUsernameAndPass(String username,String password){

        this.Username=username;
        this.Password=password;
    }
}
