package org.example.hotelmanagmentsystem;

public interface Room extends HotelManagement{
    public abstract boolean isAvailable();
    public abstract double payment();
}
