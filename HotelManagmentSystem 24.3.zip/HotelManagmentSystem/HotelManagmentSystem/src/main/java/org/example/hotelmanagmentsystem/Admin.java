package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;

public class Admin implements User {
    @FXML
    public Label messageDone;
    @FXML
    public TextField roomNumber;
    @FXML
    public RadioButton RBaddRoom, RBdeleteRoom, RBsuite, RBsingleRoom, RBdoubleRoom;
    private String Username = "Admin";
    private String Password = "ADMIN";
    private Single single;
    private Double D_room;
    private Suite suite;
    navigate n = new navigate();

    public void backToWelcome(ActionEvent event) throws IOException {
        n.backToWelcome(event);
    }

    public void doneButton(ActionEvent event) throws IOException {
        if (RBaddRoom.isSelected()) {
            addRoom();
        } else if (RBdeleteRoom.isSelected()) {
            deleteRoom();
        }
    }

    public void addRoom() throws IOException {
        messageDone.setText("");
        if (RBaddRoom.isSelected()) {
            List<String> numberSingleRoom = new ArrayList<>();
            String lineNumber;
            String typeRoom;
            String available;
            boolean check = true;
            if (RBsingleRoom.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Singleroom.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[0].equals(roomNumber.getText())) {
                        check = false;
                    } else {
                        check = true;
                    }
                }

                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Singleroom.txt", true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                if (check) {
                    fw.write(roomNumber.getText() + ",");
                    fw.write("SingleRoom,");
                    fw.write("true\n");
                    messageDone.setText("add single room is successfully");
                    Single single = new Single();
                    single.setNumber(parseInt(roomNumber.getText()));
                    List<Single> singleList = new ArrayList<>();
                    singleList.add(single);
                } else {
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
            if (RBdoubleRoom.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Doubleroom.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[0].equals(roomNumber.getText())) {
                        check = false;
                    } else {
                        check = true;
                    }
                }

                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Doubleroom.txt", true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                if (check) {
                    fw.write(roomNumber.getText() + ",");
                    fw.write("DoubleRoom,");
                    fw.write("true\n");
                    messageDone.setText("add Double room is successfully");
                    Double D_room = new Double();
                    D_room.setNumber(parseInt(roomNumber.getText()));
                    List<Double> D_roomList = new ArrayList<>();
                    D_roomList.add(D_room);
                } else {
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
            if (RBsuite.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Suite.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[0].equals(roomNumber.getText())) {
                        check = false;
                    } else {
                        check = true;
                    }
                }

                br.close();
                FileWriter fw;
                {
                    try {
                        fw = new FileWriter("Suite.txt", true);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                if (check) {
                    fw.write(roomNumber.getText() + ",");
                    fw.write("Suite,");
                    fw.write("true\n");
                    messageDone.setText("add Suite room is successfully");
                    Suite suite = new Suite();
                    suite.setNumber(parseInt(roomNumber.getText()));
                    List<Suite> suiteList = new ArrayList<>();
                    suiteList.add(suite);
                } else {
                    messageDone.setText("room is already exist");
                }
                fw.close();
            }
        }
    }

    public void deleteRoom() throws IOException {
        BufferedReader br;
        boolean exist = false;
        String Line;
        if (RBdeleteRoom.isSelected()) {
            if (RBsuite.isSelected()) {
                List<String> suiteinfo = new ArrayList<>();
                try {
                    br = new BufferedReader(new FileReader("Suite.txt"));
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                String line ;
                while ((line = br.readLine())!= null) {
                    String[]data=line.split(",");
                    if (!(data[0].equals(roomNumber.getText()))){
                        suiteinfo.add(line);
                    }else {
                        exist=true;
                    }
                }
                br.close();
                BufferedWriter bw = new BufferedWriter(new FileWriter("Suite.txt"));
                for (String info : suiteinfo) {
                    bw.write(info);
                    bw.newLine();

                }bw.close();

                if (exist) {
                    messageDone.setText("deleted is successfully");
                } else {
                    messageDone.setText("suite is not exist");
                }
            }else if (RBsingleRoom.isSelected()) {
                    List<String> singleInfo = new ArrayList<>();
                    try {
                        br = new BufferedReader(new FileReader("Singleroom.txt"));
                    } catch (FileNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] data = line.split(",");
                        if (!(data[0].equals(roomNumber.getText()))) {
                            singleInfo.add(line);
                        } else {
                            exist = true;
                        }
                    }
                    br.close();
                    BufferedWriter bw = new BufferedWriter(new FileWriter("Singleroom.txt"));
                    for (String info : singleInfo) {
                        bw.write(info);
                        bw.newLine();

                    }
                    bw.close();

                    if (exist) {
                        messageDone.setText("deleted is successfully");
                    } else {
                        messageDone.setText("Single room is not exist");
                    }
                }else if (RBdoubleRoom.isSelected()) {
                    if (RBdoubleRoom.isSelected()) {
                        List<String> doubleInfo = new ArrayList<>();
                        try {
                            br = new BufferedReader(new FileReader("Doubleroom.txt"));
                        } catch (FileNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                        String line ;
                        while ((line = br.readLine())!= null) {
                            String[]data=line.split(",");
                            if (!(data[0].equals(roomNumber.getText()))){
                                doubleInfo.add(line);
                            }else {
                                exist=true;
                            }
                        }
                        br.close();
                        BufferedWriter bw = new BufferedWriter(new FileWriter("Doubleroom.txt"));
                        for (String info : doubleInfo) {
                            bw.write(info);
                            bw.newLine();

                        }bw.close();

                        if (exist) {
                            messageDone.setText("deleted is successfully");
                        } else {
                            messageDone.setText("Double room is not exist");
                        }
        }
    }
            }
        }



    @Override
    public boolean Login(String user, String pass) throws IOException {
        return this.Username.equals(user) && this.Password.equals(pass);
    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    @Override
    public boolean editProfile(String user, String pass1, String pass) throws IOException {
        return false;
    }

    /**
     *
     */


    /**
     *
     */
    @Override
    public void viewProfile() {

    }
}