package org.example.hotelmanagmentsystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Guest implements User{
    private String Username;
    private String Password;
    private String EmailAddress;
    private String PhoneNumber;
    private boolean canBook;
    private double Payment;

    //Methods
    public String getUsername() {
        return Username;
    }
    public String getEmailAddress(){
        return EmailAddress;
    }
    public String getPhoneNumber(){
        return PhoneNumber;
    }

    public void SignUp(){
        try (BufferedWriter fileWriter = new BufferedWriter(new FileWriter("guest.txt", true))) {
            fileWriter.append(this.Username).append(",").append(this.Password).append(",").append(this.EmailAddress).append(",").append(this.PhoneNumber).append("\n");

        } catch (IOException e) {
           // System.out.println("Error writing to file: " + e.getMessage());
        }
    }
    public void setPayment(double payment) {
        this.Payment = payment;
    }
    public void setRequest(boolean b){
        if(b){
            this.Payment+=200;
        }
    }
    public void Book(){

    }
    public void Pay(){
            this.Payment=0;
    }
    /**
     *
     */
    @Override
    public boolean Login(String user,String pass) throws IOException {
        boolean find = false;
        List<Guest> guestList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("guest.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data[0].equals(user) && data[1].equals(pass)) {
                find = true;
            }
        }
        br.close();
        return find;

    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    @Override
    public boolean editProfile(String user,String pass1,String pass2) throws IOException {
        boolean find=false;
        BufferedReader br=new BufferedReader(new FileReader("guest.txt"));
        List<String>guestList=new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data[0].equals(user) && data[1].equals(pass1)) {
                String newGuest=data[0]+","+pass2+","+data[2]+","+data[3];
                guestList.add(newGuest);
                find=true;
            }else {
                guestList.add(line);
            }
        }
        br.close();
        BufferedWriter fileWriter = new BufferedWriter(new FileWriter("guest.txt"));
        for (String newGuest : guestList) {
            System.out.println(guestList);
            fileWriter.write(newGuest);
            fileWriter.newLine();

        }
        fileWriter.close();

        return find;
    }


    /**
     *
     */

    /**
     *
     */
    @Override
    public void viewProfile() {

    }
    public void setUsernameAndPass(String username,String password,String emailAddress,String phoneNumber){

        this.Username=username;
        this.Password=password;
        this.EmailAddress=emailAddress;
        this.PhoneNumber=phoneNumber;

    }
}
