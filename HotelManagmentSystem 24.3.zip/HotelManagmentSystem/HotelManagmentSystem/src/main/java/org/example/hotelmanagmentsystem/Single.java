package org.example.hotelmanagmentsystem;

import java.time.LocalDate;

public class Single implements Room{
    private int Number;
    private boolean Available;
    private double Price=2000;
    private boolean Service;
    private LocalDate Start;
    private LocalDate end;
    private Guest guest;
    /**
     *
     */
    @Override
    public boolean isAvailable() {
        return this.Available;
    }

    /**
     *
     */
    @Override
    public double payment() {
        return 0;
    }
    public void setStart() {


    }

    public void setEnd() {

    }

    public void setNumber(int number) {
        this.Number=number;

    }
    public void setAvailable(boolean b) {
        this.Available=b;

    }
    public void getStart(){

    }
    public void getEnd(){

    }
    public int getNumber(){
        return this.Number;
    }
    public void setPrice(double price){

    }
    public void getPrice(){

    }
}
