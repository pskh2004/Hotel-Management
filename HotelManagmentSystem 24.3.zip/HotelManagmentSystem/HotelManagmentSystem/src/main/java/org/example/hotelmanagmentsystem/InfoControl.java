package org.example.hotelmanagmentsystem;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;

public class InfoControl {
    @FXML
    private TextField t1,t2,t3,t4,t5,t6;
    @FXML
    private Button b1,b2,b3,b4;
    @FXML
    private Label l1;
    navigate n=new navigate();
    public void checker(ActionEvent event) throws IOException {

        if (!t1.getText().isEmpty()&&!t2.getText().isEmpty()&&!t3.getText().isEmpty()&&!t4.getText().isEmpty()&&!t5.getText().isEmpty()&&!t6.getText().isEmpty()) {
            if (parseInt(t3.getText())>=18&&parseInt(t3.getText())<120){
                if (t4.getText().startsWith("0") && t4.getText().length()==10){
                    if (t6.getText().startsWith("09") && t6.getText().length()==11) {
                        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("Info.txt"));
                        bufferedWriter.write(t1.getText() + "," + t2.getText() + "," + t3.getText() + "," + t4.getText() + "," + t5.getText() + "," + t6.getText() + "\n");
                        bufferedWriter.newLine();
                        bufferedWriter.close();
                        n.toPaymentPage(event);
                    }
                    else {
                        l1.setText("Invalid Phone Number");
                    }

                }else {
                    l1.setText("Invalid format for National ID");
                }
            }else {
                l1.setText("Invalid Age");
            }
        }else {
            l1.setText("Please enter all the details");
        }
    }
    public  void logout(ActionEvent event) throws IOException {
        n.exit(event);
    }
    public void edit(ActionEvent event) throws IOException {
        n.toSettingPageGue(event);
    }
    public void back(ActionEvent event) throws IOException {
        n.toReservePage(event);
    }
}
