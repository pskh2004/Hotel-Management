package org.example.hotelmanagmentsystem;

import java.time.LocalDate;

public class Suite implements Room {
    private int Number;
    private boolean Available;
    private double Price=7000;
    private boolean Service;
    private LocalDate Start;
    private LocalDate End;
    private Guest guest;

    /**
     *
     */
    @Override
    public boolean isAvailable() {
        return false;
    }

    /**
     *
     */
    @Override
    public double payment() {
        return 0;
    }

    public void setStart() {


    }

    public void setEnd() {

    }

    public void setNumber(int number) {


    }
    public void getStart(){

    }
    public void getEnd(){

    }
    public void getNumber(){

    }
    public void setPrice(){

    }
    public void getPrice(){

    }

}

