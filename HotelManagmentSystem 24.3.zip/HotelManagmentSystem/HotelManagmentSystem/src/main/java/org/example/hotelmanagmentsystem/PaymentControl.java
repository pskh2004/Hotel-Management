package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;

import java.io.IOException;
import java.util.Timer;

public class PaymentControl {
    @FXML
    private Button pay,back,logout;
    @FXML
    private RadioButton r1,r2,r3,r4;
    @FXML
    private Label l1,l2,l3;
    @FXML
    private CheckBox c1;
    navigate n=new navigate();
    public void pay(ActionEvent event) {
        ReserveControl re=new ReserveControl();
        double x=re.price*7000;
        if (c1.isSelected()){
            x+=200;
            l1.setText(String.valueOf(250));
        }else {
            x+=50;
            l1.setText(String.valueOf(50));
        }
        l2.setText(String.valueOf(x));


    }
    public void back(ActionEvent event) throws IOException {
        n.toInformationPage(event);
    }
    public void logout(ActionEvent event) throws IOException {
        n.Exit(event);
    }
    public void r1(ActionEvent event) throws IOException, InterruptedException {
        l3.setText("Payment was successful");
        Thread.sleep(5000);
        n.backToWelcome(event);
    }
}
