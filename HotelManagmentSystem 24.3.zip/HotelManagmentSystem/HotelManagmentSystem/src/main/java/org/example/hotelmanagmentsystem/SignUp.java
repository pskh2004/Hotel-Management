package org.example.hotelmanagmentsystem;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SignUp {
    private Stage stage;
    private Parent root;
    @FXML
    private Button b1, b2;
    @FXML
    private Label l1;
    @FXML
    private TextField t1;
    @FXML
    private TextField t2;
    @FXML
    private TextField t3;
    @FXML
    private PasswordField t4;
    @FXML
    private PasswordField t5;
    @FXML
    private RadioButton reservationist;
    @FXML
    private RadioButton guest;
    navigate n = new navigate();
    Reservationist r = new Reservationist();
    Guest g1 = new Guest();

    public void setUsernameAndPassword(ActionEvent event) throws IOException {
        if (!t1.getText().isEmpty() && !t2.getText().isEmpty() && !t3.getText().isEmpty() && !t4.getText().isEmpty() && !t5.getText().isEmpty()) {


            if (t1.getText().endsWith("@gmail.com")) {
                if (t2.getText().length() == 11 && t2.getText().startsWith("09")) {


                    if (t4.getText().equals(t5.getText())) {
                        if (t4.getText().length() >= 8) {
                            if (reservationist.isSelected()) {
                                boolean flag = false;
                                BufferedReader br = new BufferedReader(new FileReader("reservationist.txt"));
                                String line;
                                while ((line = br.readLine()) != null) {
                                    String[] str = line.split(",");
                                    if (t3.getText().equals(str[0])) {
                                        l1.setText("Username is already taken");
                                        flag = true;
                                        break;
                                    }
                                }

                                if (!flag) {
                                    r.setUsernameAndPass(t3.getText(), t4.getText(), t2.getText(), t1.getText());
                                    r.SignUp();
                                    n.backToWelcome(event);
                                }

                                br.close();
                            } else if (guest.isSelected()) {
                                boolean flag = false;
                                BufferedReader br = new BufferedReader(new FileReader("guest.txt"));
                                String line;
                                while ((line = br.readLine()) != null) {
                                    String[] g = line.split(",");
                                    if (t3.getText().equals(g[0])) {
                                        l1.setText("Username is already taken");
                                        flag = true;
                                        break;

                                    }
                                }
                                if (!flag) {
                                    g1.setUsernameAndPass(t3.getText(), t4.getText(), t2.getText(), t1.getText());
                                    g1.SignUp();
                                    n.backToWelcome(event);
                                }
                                br.close();
                            }

                        } else {
                            l1.setText("Your password must be at least 8 character");
                        }

                    } else {
                        l1.setText("Passwords are not the same!");
                    }


                } else {
                    l1.setText("Please enter a valid phone number");
                }
            }else {
            l1.setText("Email format is wrong");
            }
        }else{
            l1.setText("Please enter all wanted information");

        }


}
    public void BackToWelcome(ActionEvent event) throws IOException {
        n.backToWelcome(event);
    }
}
