package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReserveControl {
        public double price;
        @FXML
        private Label roomLabel,l1; // Assuming you have an FXML file with this label
        @FXML
        private DatePicker d1,d2;
        @FXML
        private Button show,next,back,logout,edit;
        @FXML
        private RadioButton r1,r2,r3;
        @FXML
        private TextField t1;
        Login login=new Login();
        Guest g=new Guest();
        navigate n=new navigate();
        public void Show(ActionEvent event) throws IOException {
            boolean find = false;

            if (r1.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Suite.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        roomLabel.setText("Number: " + data[0] + ",RoomType: " + data[1] + "\n ");
                    }
                }
            } else if (r2.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Singleroom.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        roomLabel.setText("Number: " + data[0] + ",RoomType: " + data[1] + "\n ");
                    }
                }
                br.close();
            } else if (r3.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Doubleroom.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        roomLabel.setText("Number: " + data[0] + "\nRoomType: " + data[1] + "\n ");
                    }

                }

            }
        }
        public void next(ActionEvent event) throws IOException {
            boolean find=false;
            if(r1.isSelected()) {
                if(d1.getValue().compareTo(d2.getValue()) > 0) {
                    l1.setText("start Date is after end Date");
                }
                else if(d1.getValue().compareTo(d2.getValue()) < 0) {
                    double daysbetween = ChronoUnit.DAYS.between(d1.getValue(), d2.getValue());
                    price=daysbetween;

                }
                else if(d1.getValue().compareTo(d2.getValue()) == 0) {
                    l1.setText("startDate is equal");
                }

                List<String>suiteList=new ArrayList<>();
                BufferedReader br=new BufferedReader(new FileReader("Suite.txt"));

                String line;

                while ((line=br.readLine())!=null){
                    String[] data=line.split(",");
                        if(data[0].equals(t1.getText())){
                            String newSuite=(data[0]+","+data[1]+",false");
                            find=true;
                            suiteList.add(newSuite);
                        }else {
                            suiteList.add(line);
                        }

                }
                br.close();
                BufferedWriter bw=new BufferedWriter(new FileWriter("Suite.txt"));
                for (String newSuite:suiteList){
                    bw.write(newSuite);
                    bw.newLine();
                }
                bw.close();


            }else if(r2.isSelected()) {
                if(d1.getValue().compareTo(d2.getValue()) > 0) {
                    l1.setText("start Date is after end Date");
                }
                else if(d1.getValue().compareTo(d2.getValue()) < 0) {
                    double daysbetween = ChronoUnit.DAYS.between(d1.getValue(), d2.getValue());
                    price=daysbetween;

                }
                else if(d1.getValue().compareTo(d2.getValue()) == 0) {
                    l1.setText("startDate is equal");
                }

                List<String>singleList=new ArrayList<>();
                BufferedReader br=new BufferedReader(new FileReader("Singleroom.txt"));
                String line;
                while ((line=br.readLine())!=null){
                    String[] data=line.split(",");

                        if(data[0].equals(t1.getText())){
                            String newSingle=(data[0]+","+data[1]+",false");
                            find=true;
                            singleList.add(newSingle);
                        }else {
                            singleList.add(line);
                        }

                }
                br.close();
                BufferedWriter bw=new BufferedWriter(new FileWriter("Singleroom.txt"));
                for (String newSingle:singleList){
                    bw.write(newSingle);
                    bw.newLine();
                }
                bw.close();


            }else if(r3.isSelected()) {
                if(d1.getValue().compareTo(d2.getValue()) > 0) {
                    l1.setText("start Date is after end Date");
                }
                else if(d1.getValue().compareTo(d2.getValue()) < 0) {
                    double daysbetween = ChronoUnit.DAYS.between(d1.getValue(), d2.getValue());
                    price=daysbetween;

                }
                else if(d1.getValue().compareTo(d2.getValue()) == 0) {
                    l1.setText("startDate is equal");
                }

                List<String>doubleList=new ArrayList<>();
                BufferedReader br=new BufferedReader(new FileReader("Doubleroom.txt"));
                String line;
                while ((line=br.readLine())!=null){
                    String[] data=line.split(",");

                        if(data[0].equals(t1.getText())){
                            String newDouble=(data[0]+","+data[1]+",false");
                            find=true;
                            doubleList.add(newDouble);
                        }else {
                            doubleList.add(line);
                        }

                }
                br.close();
                BufferedWriter bw=new BufferedWriter(new FileWriter("Suite.txt"));
                for (String newDouble:doubleList){
                    bw.write(newDouble);
                    bw.newLine();
                }
                bw.close();

            }
            n.toInformationPage(event);
        }
        public void back(ActionEvent event) throws IOException {
            n.toGuestPage(event);
        }
        public void edit(ActionEvent event) throws IOException {
            n.toSettingPageGue(event);
        }
        public void logout(ActionEvent event) throws IOException {
            n.exit(event);
        }


}