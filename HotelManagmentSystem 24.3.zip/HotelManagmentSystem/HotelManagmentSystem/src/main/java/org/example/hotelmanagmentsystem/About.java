package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class About {
    @FXML
    private Button b1;
    navigate n=new navigate();
    public void back(ActionEvent event) throws IOException {
        n.backToWelcome(event);
    }
}
