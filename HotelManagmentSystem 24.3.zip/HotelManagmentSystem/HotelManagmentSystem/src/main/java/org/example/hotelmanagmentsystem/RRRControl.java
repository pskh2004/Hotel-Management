package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class RRRControl {
    @FXML
    private Button b1, b2, b3;
    @FXML
    private RadioButton r1, r2, d1, d2, d3;
    @FXML
    private Label l1;
    navigate n = new navigate();

    public void back(ActionEvent event) throws IOException {
        n.Exit(event);
    }

    public void edit(ActionEvent event) throws IOException {
        n.toSettingPageRes(event);
    }

    public void Show(ActionEvent event) throws IOException {
        if (d1.isSelected()) {
            if (r1.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Singleroom.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        String empty = data[0];
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are busy");
                } else {
                    l1.setText(String.valueOf(list));

                }
                br.close();
            } else if (r2.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Singleroom.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("false")) {
                        String empty = data[0] ;
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are Empty");
                } else {
                    l1.setText(String.valueOf(list));

                }
                br.close();
            }

        } else if (d2.isSelected()) {
            if (r1.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Doubleroom.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        String empty = data[0] ;
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are busy");
                } else {
                    l1.setText(String.valueOf(list));

                }
                br.close();
            } else if (r2.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Doubleroom.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("false")) {
                        String empty = data[0];
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are Empty");
                } else {
                    l1.setText(String.valueOf(list));
                    br.close();
                }
            }
        } else if (d3.isSelected()) {
            if (r1.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Suite.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("true")) {
                        String empty = data[0];
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are busy");
                } else {
                    l1.setText(String.valueOf(list));
                }

                br.close();
            } else if (r2.isSelected()) {
                BufferedReader br = new BufferedReader(new FileReader("Suite.txt"));
                List<String> list = new ArrayList<>();
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data[2].equals("false")) {
                        String empty = data[0] ;
                        list.add(empty);
                    }
                }
                if (list.isEmpty()) {
                    l1.setText("All the rooms are Empty");
                } else {
                    l1.setText(String.valueOf(list));
                }

                br.close();
            }


        }
    }
}

