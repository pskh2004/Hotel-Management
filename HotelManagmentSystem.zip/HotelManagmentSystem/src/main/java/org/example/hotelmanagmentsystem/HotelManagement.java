package org.example.hotelmanagmentsystem;

public interface HotelManagement {
}
