package org.example.hotelmanagmentsystem;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface User extends HotelManagement{
    public abstract boolean Login(String user,String pass) throws IOException;
    public abstract void Logout();
    public abstract boolean editProfile(String user,String pass1,String pass) throws IOException;
    public abstract void viewProfile();
}
