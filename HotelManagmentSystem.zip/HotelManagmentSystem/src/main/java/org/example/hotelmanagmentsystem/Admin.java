package org.example.hotelmanagmentsystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Admin implements User{
    private String Username="Admin";
    private String Password="ADMIN";
    private Single single;
    private Double D_room;
    private Suite suite;
    public void addSingleRoom(){
        int Number = 0;
        Single single=new Single();
        single.setNumber(Number);
        List<Single> singleList=new ArrayList<>();
        singleList.add(single);



    }
    public void addDoubleRoom(){
        int Number=0;
        Double D_room=new Double();
        D_room.setNumber(Number);
        List<Double>D_roomList=new ArrayList<>();
        D_roomList.add(D_room);



    }
    public void addSuiteRoom(){
        int Number=0;
        Suite suite=new Suite();
        suite.setNumber(Number);
        List<Suite>suiteList=new ArrayList<>();
        suiteList.add(suite);



    }

    public void deleteRoom(){

    }


    @Override
    public boolean Login(String user, String pass) throws IOException {
        return this.Username.equals(user) && this.Password.equals(pass);
    }

    /**
     *
     */
    @Override
    public void Logout() {

    }

    @Override
    public boolean editProfile(String user, String pass1, String pass) throws IOException {
        return false;
    }

    /**
     *
     */


    /**
     *
     */
    @Override
    public void viewProfile() {

    }
}

