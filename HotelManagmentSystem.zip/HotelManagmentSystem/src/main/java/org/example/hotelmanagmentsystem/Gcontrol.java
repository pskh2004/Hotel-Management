package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class Gcontrol {
    @FXML
    private Button b1,b2,b3,b4;
    navigate n=new navigate();
    public void B1(ActionEvent event) throws IOException {
        n.toReservePage(event);
    }
    public void B2(ActionEvent event) throws IOException {
        n.toPaymentPage(event);
    }
    public void B3(ActionEvent event) throws IOException {
        n.toSettingPageGue(event);
    }
    public void B4(ActionEvent event) throws IOException {
        n.Exit(event);
    }
}
