package org.example.hotelmanagmentsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;

public class REdit {
    @FXML
    private TextField T1;
    @FXML
    private Button b1;
    @FXML
    private Button b2;
    @FXML
    private PasswordField t2;
    @FXML
    private PasswordField t3;
    @FXML
    private Label l1;
    Reservationist r=new Reservationist();

    navigate n=new navigate();
    public void Edit(ActionEvent event) throws IOException {
        if(!T1.getText().isEmpty()&&!t2.getText().isEmpty()&&!t3.getText().isEmpty()) {
            if (t3.getText().length()>=8){
                if(r.editProfile(T1.getText(),t2.getText(),t3.getText())){
                    n.backFromSettingRes(event);
                }else {
                    l1.setText("Username or Password is incorrect.");
                }
            }else {
                l1.setText("Password must be at least 8 characters.");
            }

        }else {
            l1.setText("Please enter all fields.");
        }


    }
    public void back(ActionEvent event) throws IOException {
        n.backFromSettingGue(event);
    }

}

