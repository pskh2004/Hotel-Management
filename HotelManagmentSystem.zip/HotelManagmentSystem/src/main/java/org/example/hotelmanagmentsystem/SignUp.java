package org.example.hotelmanagmentsystem;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.io.IOException;

public class SignUp {
    private Stage stage;
    private Parent root;
    @FXML
    private Button b1,b2;
    @FXML
    private Label l1;
    @FXML
    private TextField t1;
    @FXML
    private TextField t2;
    @FXML
    private TextField t3;
    @FXML
    private PasswordField t4;
    @FXML
    private PasswordField t5;
    @FXML
    private RadioButton reservationist;
    @FXML
    private RadioButton guest;
    navigate n = new navigate();
    Reservationist r=new Reservationist();
    Guest g=new Guest();
    public void setUsernameAndPassword(ActionEvent event) throws IOException {
        if (!t1.getText().isEmpty()&&!t2.getText().isEmpty()&&!t3.getText().isEmpty()&&!t4.getText().isEmpty()&&!t5.getText().isEmpty()) {
            if (t1.getText().endsWith("@gmail.com"))
            {
                if (t2.getText().length()==11&&t2.getText().startsWith("09")){


            if (t4.getText().equals(t5.getText())) {
                if (t4.getText().length() >= 8) {
                    if (reservationist.isSelected()) {

                        r.setUsernameAndPass(t3.getText(), t4.getText(),t2.getText(),t1.getText());
                        r.SignUp();
                        n.backToWelcome(event);
                    } else if (guest.isSelected()) {
                        g.setUsernameAndPass(t3.getText(), t4.getText(),t2.getText(),t1.getText());
                        g.SignUp();
                        n.backToWelcome(event);
                    }


                } else {
                    l1.setText("Your password must be at least 8 character");
                }

            } else {
                l1.setText("Passwords are not the same!");
            }


        }else{
                    l1.setText("Please enter a valid phone number");
                }
            } else {
                l1.setText("Email format is wrong");
            }
        } else {
            l1.setText("Please enter all wanted information");

        }

    }
    public void BackToWelcome(ActionEvent event) throws IOException {
        n.backToWelcome(event);
    }
}
