package org.example.hotelmanagmentsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;

public class navigate {
    private Stage stage;
    private Parent root;
    public void exit(ActionEvent event) {
        System.exit(0);
    }
    public void toLoginPage(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void toSignupPage(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("signUp.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    public RadioButton reservationist , guest , admin ;
    public void choiceTitleSU (ActionEvent event) throws IOException {
        if (reservationist.isSelected()) {
            guest.setSelected(false);
        } else if (guest.isSelected()) {
            reservationist.setSelected(false);
        }
    }
    public void backToWelcome(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void choiceTitle (ActionEvent event) throws IOException {
        if(reservationist.isSelected()){
            guest.setSelected(false);
            admin.setSelected(false);
        }
        else if(guest.isSelected()){
            reservationist.setSelected(false);
            admin.setSelected(false);
        }
        else if(admin.isSelected()){
            reservationist.setSelected(false);
            guest.setSelected(false);
        }
    }
    public void login(ActionEvent event) throws IOException {
        if(reservationist.isSelected()){
            stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("reservationist.fxml"));
            stage.setTitle("Hotel Management System");
            stage.setScene(new Scene(root));
            stage.show();
        }
        else if(guest.isSelected()){
            stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("guest.fxml"));
            stage.setTitle("Hotel Management System");
            stage.setScene(new Scene(root));
            stage.show();
        }
        else if(admin.isSelected()){
            stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("admin.fxml"));
            stage.setTitle("Hotel Management System");
            stage.setScene(new Scene(root));
            stage.show();
        }
    }
    public void toSettingPageRes(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("settingreservationist.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void toSettingPageGue(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("settingguest.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void backFromSettingRes(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("reservationist.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
    public void backFromSettingGue(ActionEvent event) throws IOException {
        stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("guest.fxml"));
        stage.setTitle("Hotel Management System");
        stage.setScene(new Scene(root));
        stage.show();
    }
}
