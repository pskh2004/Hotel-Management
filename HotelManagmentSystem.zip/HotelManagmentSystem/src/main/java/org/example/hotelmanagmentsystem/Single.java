package org.example.hotelmanagmentsystem;

import java.time.LocalDate;

public class Single implements Room{
    private int Number;
    private boolean Available;
    private double Price=20000;
    private boolean Service;
    private LocalDate Start;
    private LocalDate end;
    private Guest guest;
    /**
     *
     */
    @Override
    public boolean isAvailable() {
        return false;
    }

    /**
     *
     */
    @Override
    public double payment() {
        return 0;
    }
    public void setStart() {


    }

    public void setEnd() {

    }

    public void setNumber(int number) {


    }
    public void getStart(){

    }
    public void getEnd(){

    }
    public void getNumber(){

    }
    public void setPrice(double price){

    }
    public void getPrice(){

    }
}
