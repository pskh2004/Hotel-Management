package org.example.hotelmanagmentsystem;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;


import java.io.IOException;

public class Login {
    @FXML
    private Label l1;
    @FXML
    private TextField t1;
    @FXML
    private PasswordField t2;
    @FXML
    private Button b1;
    @FXML
    private Button b2;
    @FXML
    private RadioButton reservationist,guest,admin;
    navigate n=new navigate();
    Reservationist r=new Reservationist();
    Guest g=new Guest();
    Admin a=new Admin();
    public void LoginButton(ActionEvent event) throws IOException{
        if (!t1.getText().isEmpty()&&!t2.getText().isEmpty()){
            if (reservationist.isSelected()){
                if(r.Login(t1.getText(), t2.getText())){
                    n.toReservationistPage(event);
                }else {
                    l1.setText("Username or Password is incorrect");
                }
            } else if (guest.isSelected()) {
                if (g.Login(t1.getText(), t2.getText())){
                    n.toGuestPage(event);
                }else {
                    l1.setText("Username or Password is incorrect");
                }

            } else if (admin.isSelected()) {
                if (a.Login(t1.getText(), t2.getText())){
                    n.toAdminPage(event);
                }else {
                    l1.setText("Username or Password is incorrect");
                }

            }
        }else {
            l1.setText("Please enter all fields");
        }
    }

    public void BackButton(ActionEvent event) throws IOException{
        n.backToWelcome(event);
    }
}
