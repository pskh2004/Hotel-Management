package org.example.hotelmanagmentsystem;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;

import java.io.IOException;


public class RControl {
    @FXML
    private Button b1,b2,b3;
    @FXML
    private RadioButton r1,r2;
    @FXML
    private Label l1;
    navigate n=new navigate();
    public void b1(ActionEvent event) throws IOException {
        n.toSettingPageRes(event);
    }
    public void b2(ActionEvent event) throws IOException {
        n.Exit(event);
    }
}
