package org.example.hotelmanagmentsystem;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Reservationist implements User {
    private String Username;
    private String Password;
    private String EmailAddress;
    private String PhoneNumber;
    private Single single;
    private Double D_room;
    private Suite suite;
    /**
     *
     */
    public  void SignUp(){

        try (BufferedWriter fileWriter = new BufferedWriter(new FileWriter("reservationist.txt", true))) {
            fileWriter.append(this.Username).append(",").append(this.Password).append(",").append(this.EmailAddress).append(",").append(this.PhoneNumber).append("\n");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
    public void Check_in(){

    }
    public void Check_out(){

    }

    @Override
    public boolean Login(String user,String pass) throws IOException {
        boolean find = false;
        List<Reservationist> reservationistList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("reservationist.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data[0].equals(user) && data[1].equals(pass)) {
                find = true;
            }
        }
        br.close();
        return find;

    }
    /**
     *
     */
    @Override
    public void Logout() {

    }

    /**
     *
     */
    @Override
    public boolean editProfile(String user,String pass1,String pass2) throws IOException {
        boolean find=false;
        BufferedReader br=new BufferedReader(new FileReader("reservationist.txt"));
        List<String>reservationistList=new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(",");
            if (data[0].equals(user) && data[1].equals(pass1)) {
                String newReservationist=data[0]+","+pass2+","+data[2]+","+data[3];
                reservationistList.add(newReservationist);
                find=true;
            }else {
                reservationistList.add(line);
            }
        }
        br.close();
        BufferedWriter fileWriter = new BufferedWriter(new FileWriter("reservationist.txt"));
        for (String newReservationist : reservationistList) {

            fileWriter.write(newReservationist);
            fileWriter.newLine();

        }
        fileWriter.close();

        return find;
    }


    @Override
    public void viewProfile() {

    }




    /**
     *
     */
    public void setUsernameAndPass(String username,String password,String emailAddress,String phoneNumber){

        this.Username=username;
        this.Password=password;
        this.EmailAddress=emailAddress;
        this.PhoneNumber=phoneNumber;

    }

}